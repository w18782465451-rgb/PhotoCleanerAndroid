# 如何生成可安装 APK

当前交付包包含完整 Android Studio 项目和 GitHub Actions 构建工作流。此工作环境没有 Android SDK/Gradle，因此不能在这里直接编译并验证 APK。

## 推荐方式：GitHub Actions 云端构建
1. 解压 `PhotoCleanerAndroid-project.zip`。
2. 在 GitHub 新建一个空仓库，例如 `PhotoCleanerAndroid`。
3. 将解压后的项目全部文件上传到仓库根目录，并提交到 `main` 分支。
4. 打开仓库的 **Actions** 页面，选择 **Build Android APK** 工作流；如果未自动运行，点击 **Run workflow**。
5. 等待任务完成，在该次运行页面底部的 **Artifacts** 下载 `PhotoCleaner-debug-apk`。
6. 解压后得到 `app-debug.apk`，传到安卓手机安装。首次安装时按系统提示允许该来源安装应用。

## 本地方式
使用 Android Studio（JDK 17、Android SDK Platform 35）打开项目，等待 Gradle Sync，然后选择 **Build > Build Bundle(s) / APK(s) > Build APK(s)**。

## 注意
这是 debug 测试包，不是上架签名包。首次扫描大量照片可能较慢；相似识别基于轻量平均哈希，可能误判，务必预览后再删除。
