# 照片清理助手（Android）

一个本地运行的 Android 相册重复/相似照片筛选 MVP。

## 功能
- 使用 MediaStore 读取设备图片
- SHA-256 识别文件内容完全相同的照片
- 8x8 平均哈希（aHash）初筛相似照片
- 预览照片并手动勾选
- Android 11+ 使用系统删除确认弹窗
- 不请求网络权限，不上传照片

## 构建 APK
要求：Android Studio、JDK 17、Android SDK 35。

1. 使用 Android Studio 打开项目根目录。
2. 等待 Gradle Sync 完成。
3. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
4. Debug APK 输出位置：`app/build/outputs/apk/debug/app-debug.apk`。

也可以在已安装 Android SDK 的环境运行：
`gradle assembleDebug`

## GitHub Actions 自动构建
将项目推送到 GitHub 后，工作流会构建 APK 并作为 Artifact 提供下载。

## 注意
这是首个可运行原型。相似照片使用轻量 aHash 阈值，可能出现误判；建议逐张预览。
扫描会读取图片内容并计算哈希，首次扫描大量照片可能耗时较长。正式发布前建议加入分页/缩略图缓存、后台任务、Android 14 部分照片访问适配和更完善的异常处理。
