package com.example.photocleaner

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.security.MessageDigest
import java.util.concurrent.Executors
import kotlin.math.abs

data class Photo(
    val uri: Uri,
    val name: String,
    val size: Long,
    val date: Long,
    val sha: String,
    val hash: Long
)

data class PhotoGroup(val photos: List<Photo>, val exact: Boolean)

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private val selectedUris = linkedSetOf<Uri>()
    private var groups: List<PhotoGroup> = emptyList()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) scan(false) else toast("需要照片读取权限才能扫描相册")
        }

    private val deleteLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                toast("已按系统确认结果完成清理")
                selectedUris.clear()
                scan(false)
            } else toast("未删除照片")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (hasPermission()) scan(false)
        else permissionLauncher.launch(readPermission())
    }

    private fun readPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPermission() =
        checkSelfPermission(readPermission()) == PackageManager.PERMISSION_GRANTED

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 18)
            setBackgroundColor(0xFFF7F8FA.toInt())
        }
        val title = TextView(this).apply {
            text = "照片清理助手"
            textSize = 25f
            setTextColor(0xFF172033.toInt())
            setPadding(0, 0, 0, 8)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "本地扫描 · 不上传照片 · 删除前由你确认"
            textSize = 13f
            setTextColor(0xFF667085.toInt())
        }
        status = TextView(this).apply {
            text = "准备扫描手机相册"
            textSize = 15f
            setTextColor(0xFF344054.toInt())
            setPadding(0, 20, 0, 8)
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dup = makeButton("查找重复")
        dup.setOnClickListener { if (hasPermission()) scan(true) else permissionLauncher.launch(readPermission()) }
        val sim = makeButton("查找相似")
        sim.setOnClickListener { if (hasPermission()) scan(false) else permissionLauncher.launch(readPermission()) }
        buttons.addView(dup, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 6 })
        buttons.addView(sim, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = 6 })
        val clean = makeButton("删除已勾选照片")
        clean.setOnClickListener { requestDelete() }

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(content) }

        page.addView(title)
        page.addView(subtitle)
        page.addView(status)
        page.addView(progress)
        page.addView(buttons)
        page.addView(clean, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10; bottomMargin = 12 })
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
    }

    private fun scan(exactOnly: Boolean) {
        status.text = "正在扫描本地照片，请稍候……"
        progress.visibility = View.VISIBLE
        content.removeAllViews()
        selectedUris.clear()
        executor.execute {
            try {
                val photos = readPhotos()
                val found = findGroups(photos, exactOnly)
                runOnUiThread {
                    progress.visibility = View.GONE
                    groups = found
                    val count = found.sumOf { it.photos.size }
                    status.text = "扫描完成：${photos.size} 张照片，发现 ${found.size} 组${if (exactOnly) "重复" else "重复/相似"}照片"
                    renderGroups(found)
                    if (found.isEmpty()) addMessage("没有发现符合条件的照片。")
                    if (count > 0) addMessage("勾选要删除的照片，再点击“删除已勾选照片”。系统会再次要求确认。")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    status.text = "扫描失败：${e.localizedMessage ?: "未知错误"}"
                }
            }
        }
    }

    private fun readPhotos(): List<Photo> {
        val result = mutableListOf<Photo>()
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.DATE_ADDED
        )
        contentResolver.query(collection, projection, null, null,
            "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                val name = cursor.getString(nameCol) ?: "未命名照片"
                val size = cursor.getLong(sizeCol)
                val date = cursor.getLong(dateCol)
                val digest = MessageDigest.getInstance("SHA-256")
                contentResolver.openInputStream(uri)?.use { input ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        digest.update(buffer, 0, n)
                    }
                } ?: continue
                val sha = digest.digest().joinToString("") { "%02x".format(it) }
                val bitmap = decodeSmall(uri)
                val hash = bitmap?.let { averageHash(it) } ?: 0L
                bitmap?.recycle()
                result.add(Photo(uri, name, size, date, sha, hash))
            }
        }
        return result
    }


    private fun decodeSmall(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 512 || bounds.outHeight / sample > 512) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }

    private fun averageHash(source: Bitmap): Long {
        val small = Bitmap.createScaledBitmap(source, 8, 8, true)
        val pixels = IntArray(64)
        small.getPixels(pixels, 0, 8, 0, 0, 8, 8)
        small.recycle()
        val gray = pixels.map { p ->
            val r = (p shr 16) and 255
            val g = (p shr 8) and 255
            val b = p and 255
            (r * 299 + g * 587 + b * 114) / 1000
        }
        val avg = gray.average()
        var value = 0L
        gray.forEachIndexed { i, v -> if (v >= avg) value = value or (1L shl i) }
        return value
    }

    private fun findGroups(photos: List<Photo>, exactOnly: Boolean): List<PhotoGroup> {
        val result = mutableListOf<PhotoGroup>()
        val used = mutableSetOf<Int>()
        val exactMap = photos.indices.groupBy { photos[it].sha }
        exactMap.values.filter { it.size > 1 }.forEach { indexes ->
            indexes.forEach { used.add(it) }
            result.add(PhotoGroup(indexes.map { photos[it] }, true))
        }
        if (!exactOnly) {
            for (i in photos.indices) {
                if (i in used) continue
                val matches = mutableListOf(i)
                for (j in i + 1 until photos.size) {
                    if (j in used) continue
                    if (java.lang.Long.bitCount(photos[i].hash xor photos[j].hash) <= 8) {
                        matches.add(j)
                    }
                }
                if (matches.size > 1) {
                    matches.forEach { used.add(it) }
                    result.add(PhotoGroup(matches.map { photos[it] }, false))
                }
            }
        }
        return result
    }

    private fun renderGroups(items: List<PhotoGroup>) {
        items.forEachIndexed { index, group ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12, 12, 12, 12)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            val heading = TextView(this).apply {
                text = "${if (group.exact) "完全重复" else "可能相似"} · ${group.photos.size} 张"
                textSize = 16f
                setTextColor(0xFF172033.toInt())
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }
            card.addView(heading)
            group.photos.forEach { photo ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, 8, 0, 8)
                }
                val image = ImageView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(76, 76)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    try {
                        contentResolver.openInputStream(photo.uri)?.use {
                            setImageBitmap(decodeSmall(photo.uri))
                        }
                    } catch (_: Exception) {}
                }
                val check = CheckBox(this).apply {
                    text = "${photo.name}\n${formatSize(photo.size)}"
                    textSize = 13f
                    setTextColor(0xFF344054.toInt())
                    setOnCheckedChangeListener { _, checked ->
                        if (checked) selectedUris.add(photo.uri) else selectedUris.remove(photo.uri)
                    }
                }
                row.addView(image)
                row.addView(check, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = 8 })
                card.addView(row)
            }
            content.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = 12
            })
        }
    }

    private fun addMessage(message: String) {
        content.addView(TextView(this).apply {
            text = message
            textSize = 13f
            setTextColor(0xFF667085.toInt())
            setPadding(4, 8, 4, 12)
        })
    }

    private fun requestDelete() {
        if (selectedUris.isEmpty()) {
            toast("请先勾选要删除的照片")
            return
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val pending = MediaStore.createDeleteRequest(contentResolver, selectedUris.toList())
            deleteLauncher.launch(IntentSenderRequest.Builder(pending.intentSender).build())
        } else {
            toast("当前版本请在系统相册中确认删除")
        }
    }

    private fun formatSize(bytes: Long): String =
        if (bytes >= 1024 * 1024) "%.1f MB".format(bytes / 1024.0 / 1024.0)
        else "${bytes / 1024} KB"

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
    }
}
